const msgs ={
    "enter_word": "Please Enter a word",
    "enter_definition": "Enter a definition",
    "add_button": "Add",
    "search_word": "Search for a word",
    "definition": "Definition:",
    "search_button": "Search",
    "word_exists": "Word already exists in the dictionary.",
    "word_not_found": "Word not found in the dictionary.",
    "both_required": "Both 'word' and 'definition' are required.",
    "definition_here": "Definition will appear here."
}