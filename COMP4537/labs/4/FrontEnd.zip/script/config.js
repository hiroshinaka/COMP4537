window.APP_CONFIG = {
    // Point to the API server; change port if you run server2 on a different port.
    API_BASE: "https://dleecode.com/comp4537/labs/4/api/definitions/"
}
