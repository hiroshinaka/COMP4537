document.addEventListener("DOMContentLoaded", () => {
  const writer = document.querySelector('.writer');
  const reader = document.querySelector('.reader');
  writer.textContent = window.MSG.BTN_WRITER;
  reader.textContent = window.MSG.BTN_READER;

});
